# 1.6.61
## Changelog:
- Fixed Dropdown Tab Desc Width
- Added `Locked` to Dropdown Tabs;
- Added `:LockValues({})` to `Dropdown`
- Added more theme tags (more soon)
- Reworked `Toggle` and `Checkbox`